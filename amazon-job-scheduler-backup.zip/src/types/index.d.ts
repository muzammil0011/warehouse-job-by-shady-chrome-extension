interface MountContentUI {
  anchor: string;
  hostCSS?: Partial<CSSStyleDeclaration>;
  anchorCSS?: Partial<CSSStyleDeclaration>;
  anchorParentCSS?: Partial<CSSStyleDeclaration>;
  domStyle?: string;
  position?: "inline" | "overlay" | "modal";
  children: ReactNode;
}

interface Settings {
  selectedCity?: string;
  distance?: string;
  jobType?: string;
  __ap?: boolean;
  cityTags?: string[];
  lat: number;
  lng: number;
  maxInterval: number;
  minInterval: number;
  randomInterval: number;
}

type Coordinates = {
  lat: number;
  lng: number;
};

type CityCoordinates = Record<string, Coordinates>;
