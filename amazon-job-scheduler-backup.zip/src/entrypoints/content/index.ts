import "./fetch";
export default defineContentScript({
  matches: [
    "*://*.example.com/*",
    "https://hiring.amazon.ca/*",
    "*://auth.hiring.amazon.com/*",
  ],
  // 2. Set cssInjectionMode
  cssInjectionMode: "ui",

  async main(ctx) {
    (async function () {
      function simulateClick(button: HTMLElement) {
        const clickEvent = new MouseEvent("click", {
          view: window,
          bubbles: true,
          cancelable: true,
        });

        button.dispatchEvent(clickEvent);

        // Fallback click after 500ms
        setTimeout(() => {
          button.click();
        }, 500);
      }

      // Redirect to Amazon job search after 4000ms
      function redirectToAmazonJobSearch() {
        setTimeout(() => {
          window.location.href = "https://hiring.amazon.ca/app#/jobSearch";
        }, 4000);
      }

      const videos = document.querySelectorAll("video");
      videos.forEach((video) => {
        video.pause();
        video.src = "";
        video.remove();
      });

      const iframes = document.querySelectorAll("iframe");
      iframes.forEach((iframe) => {
        if (iframe.src.includes("youtube") || iframe.src.includes("vimeo")) {
          iframe.remove();
        }
      });

      // Create a MutationObserver to monitor DOM changes
      const observer = new MutationObserver((mutations) => {
        // Block newly added videos using MutationObserver
        mutations.forEach((mutation: MutationRecord) => {
          mutation.addedNodes.forEach((node: Node) => {
            if (
              node instanceof HTMLElement &&
              (node.tagName === "VIDEO" ||
                (node.tagName === "IFRAME" &&
                  (node as HTMLIFrameElement).src?.match(/youtube|vimeo/)))
            ) {
              node.remove();
            }
          });
        });

        const buttons = document.querySelectorAll("button");

        buttons.forEach((button) => {
          const label = button
            .querySelector("div[data-test-component='StencilReactRow']")
            ?.textContent?.trim();

          // If the button is labeled "Next", click it and proceed
          if (label === "Next") {
            simulateClick(button);
            observer.disconnect();

            setTimeout(() => {
              // After clicking "Next", look for "Create Application"
              const createAppButton = [
                ...document.querySelectorAll("button"),
              ].find(
                (btn) =>
                  btn
                    .querySelector("div[data-test-component='StencilReactRow']")
                    ?.textContent?.trim() === "Create Application",
              );

              if (createAppButton) {
                simulateClick(createAppButton);
                observer.disconnect();
                redirectToAmazonJobSearch();
              }
            }, 2000); // wait 2 seconds before checking for "Create Application"
          }
        });

        // Fallback: check for "Create Application" directly
        const createAppButton = [...document.querySelectorAll("button")].find(
          (btn) =>
            btn
              .querySelector("div[data-test-component='StencilReactRow']")
              ?.textContent?.trim() === "Create Application",
        );

        if (createAppButton) {
          simulateClick(createAppButton);
          observer.disconnect();
          redirectToAmazonJobSearch();
        }
      });

      // Start observing changes in the DOM
      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });
    })();

    browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "playSound") {
        console.log("Attempting to play sound...");
        const alertSound = new Audio(
          browser.runtime.getURL("alert.wav" as any),
        );
        alertSound
          .play()
          .then(() => {
            console.log("Sound played successfully.");
          })
          .catch((error) => {
            const btn = document.createElement("button");
            btn.style.display = "none";
            document.body.appendChild(btn);
            btn.addEventListener("click", () => {
              alertSound.play();
            });
            btn.click();
            document.body.removeChild(btn);
          });
      }
    });
  },
});
