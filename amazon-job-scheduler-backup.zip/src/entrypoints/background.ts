export default defineBackground(() => {
  browser.runtime.onConnect.addListener(function (port: chrome.runtime.Port) {
    port.onMessage.addListener(async function (message: { action: string }) {
      let response: {
        action: string;
        url?: string;
        data?: Record<string, any>;
      } = {
        action: message.action,
      };
      response.action = message.action;
      if (message.action == "fetch_info") {
        let { __un: d } = await browser.storage.local.get("__un"),
          { __pw: e } = await browser.storage.local.get("__pw"),
          { candidateID: f } = await browser.storage.local.get("candidateID"),
          { selectedCity: g } = await browser.storage.local.get("selectedCity"),
          { lat: h } = await browser.storage.local.get("lat"),
          { lng: i } = await browser.storage.local.get("lng"),
          { distance: j } = await browser.storage.local.get("distance"),
          { jobType: k } = await browser.storage.local.get("jobType"),
          { __ap: l } = await browser.storage.local.get("__ap"),
          m = await new Promise((n) =>
            browser.management.getSelf((o) => n(o.version)),
          );
        response.data = {
          $username: d,
          $password: e,
          $candidateID: f,
          $selectedCity: g,
          $lat: h,
          $lng: i,
          $distance: j,
          $jobType: k,
          $active: l,
          $version: m,
        };
      }
      port.postMessage(response);
    });
  });
  browser.runtime.onInstalled.addListener(
    async ({ reason }: { reason: string }) => {
      browser.action.disable(),
        browser.declarativeContent.onPageChanged.removeRules(undefined, () => {
          const rule = {
            conditions: [
              new browser.declarativeContent.PageStateMatcher({
                pageUrl: {},
              }),
            ],
            actions: [new browser.declarativeContent.ShowAction()],
          };
          browser.declarativeContent.onPageChanged.addRules([rule]);
        }),
        reason === "install" &&
          (await browser.storage.local.set({
            $active: false,
            __cr: 0,
            __fq: 0.5,
            __gp: 3,
            __tdgp: 0x3,
          }),
          browser.tabs.create({
            url: "https://hiring.amazon.ca/app#/jobSearch",
          })),
        browser.storage.onChanged.addListener((b, c) => {
          if (c === "local" && b.candidateId) {
            const d = b.candidateId.newValue;
          }
        });
    },
  );
  browser.tabs.onUpdated.addListener(
    (
      tabId: number,
      changeInfo: chrome.tabs.TabChangeInfo,
      tab: chrome.tabs.Tab,
    ) => {
      changeInfo.status === "complete" &&
        tab.url?.includes("hiring.amazon.ca/application/us/") &&
        tab.url?.includes("jobId=") &&
        browser.scripting.executeScript(
          {
            target: {
              tabId,
            },
            files: ["Createapp.js"],
          },
          () => {},
        );
    },
  );
  browser.runtime.onMessage.addListener(
    (
      message: { action: string },
      sender: chrome.runtime.MessageSender,
      sendResponse: (response?: any) => void,
    ) => {
      if (message.action === "start_fetch")
        browser.runtime.sendMessage({
          action: "start_fetch",
        });
      else
        message.action === "stop_fetch" &&
          browser.runtime.sendMessage({
            action: "stop_fetch",
          });
    },
  );
  browser.runtime.onMessage.addListener(function (
    message: { candidateId?: string },
    sender: chrome.runtime.MessageSender,
    sendResponse: (response: { status: string }) => void,
  ) {
    if (message.candidateId) {
      const candidateId = message.candidateId;
      browser.storage.local.set(
        {
          candidateId,
        },
        function () {},
      ),
        sendResponse({
          status: "success",
        });
    }
  });
});
