export const theme = {
	colors: {
		primary: "#ff6200",
	},
};
