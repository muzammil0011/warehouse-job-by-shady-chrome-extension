import { RefObject, useEffect, useState } from "react";

interface UseTextSelectionProps {
  menuRef: RefObject<HTMLDivElement | null>;
  resultRef: RefObject<HTMLDivElement | null>;
  onHide: () => void;
}

export function useTextSelection({
  menuRef,
  resultRef,
  onHide,
}: UseTextSelectionProps) {
  const [showFloating, setShowFloating] = useState(false);
  const [position, setPosition] = useState<{ x: number; y: number }>({
    x: 0,
    y: 0,
  });
  const [selectedText, setSelectedText] = useState("");

  // Helper to update position based on current selection
  const updatePositionFromSelection = () => {
    const selection = window.getSelection();
    const text = selection?.toString().trim() || "";

    if (!text) {
      setShowFloating(false);
      setSelectedText("");
      onHide();
      return;
    }

    const range = selection?.getRangeAt(0);
    const rect = range?.getBoundingClientRect();

    if (rect && rect.width !== 0 && rect.height !== 0) {
      // Position menu centered horizontally, and slightly above selection rect
      setPosition({
        x: rect.left + rect.width / 2,
        y: rect.top - 10,
      });
      setSelectedText(text);
      setShowFloating(true);
    } else {
      // If rect is zero-sized (e.g., selection out of viewport), hide menu
      setShowFloating(false);
      setSelectedText("");
      onHide();
    }
  };

  useEffect(() => {
    let selectionTimeout: NodeJS.Timeout;

    const handleMouseUp = () => {
      if (selectionTimeout) clearTimeout(selectionTimeout);
      selectionTimeout = setTimeout(() => {
        updatePositionFromSelection();
      }, 10);
    };

    const handleScrollOrResize = () => {
      if (!showFloating) return;
      updatePositionFromSelection();
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!showFloating) return;

      const selection = window.getSelection();
      const text = selection?.toString().trim() || "";

      if (!text) {
        const isOverMenu = menuRef.current?.contains(e.target as Node);
        const isOverResult = resultRef.current?.contains(e.target as Node);

        if (!isOverMenu && !isOverResult) {
          setShowFloating(false);
          setSelectedText("");
          onHide();
        }
      }
    };

    document.addEventListener("mouseup", handleMouseUp);
    document.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("scroll", handleScrollOrResize, true); // true = capture phase to catch scroll on any element
    window.addEventListener("resize", handleScrollOrResize);

    return () => {
      document.removeEventListener("mouseup", handleMouseUp);
      document.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("scroll", handleScrollOrResize, true);
      window.removeEventListener("resize", handleScrollOrResize);
      if (selectionTimeout) clearTimeout(selectionTimeout);
    };
  }, [menuRef, resultRef, onHide, showFloating]);

  return {
    showFloating,
    setShowFloating,
    position,
    selectedText,
  };
}
