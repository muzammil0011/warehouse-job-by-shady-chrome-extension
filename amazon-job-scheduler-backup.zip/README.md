# Personal Toolkit Browser Extension

A browser extension for personal utility functions.
![Personal Toolkit](src/assets/screenshot.png)

🌟 Allow Double Click To Copy
🌟 Remove Credits Element from pika.style Screenshot Editor
