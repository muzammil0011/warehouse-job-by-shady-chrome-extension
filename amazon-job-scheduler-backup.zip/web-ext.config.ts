import { defineWebExtConfig } from "wxt";

export default defineWebExtConfig({
	disabled: true,
});
