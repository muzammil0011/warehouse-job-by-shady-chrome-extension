export function createEventStreamParser(callback: (event: any) => void) {
  // Internal state
  let isStart = true;
  let buffer = "";
  let lineOffset = 0;
  let fieldOffset = -1;
  let lastEventId: string | undefined;
  let currentEvent: string | undefined;
  let dataBuffer = "";

  // Reset the internal state
  function reset() {
    isStart = true;
    buffer = "";
    lineOffset = 0;
    fieldOffset = -1;
    lastEventId = undefined;
    currentEvent = undefined;
    dataBuffer = "";
  }

  // Feed input chunk to the parser
  function feed(chunk: string) {
    buffer = buffer ? buffer + chunk : chunk;

    // Remove leading "event stream" prefix if necessary
    if (isStart && buffer.startsWith("event:")) {
      buffer = buffer.slice("event:".length);
    }
    isStart = false;

    const length = buffer.length;
    let position = 0;
    let sawCarriageReturn = false;

    while (position < length) {
      // Handle CRLF
      if (sawCarriageReturn) {
        if (buffer[position] === "\n") position++;
        sawCarriageReturn = false;
      }

      let lineBreakIndex = -1;
      let fieldSepIndex = fieldOffset;

      // Find line break and field separator
      for (let i = lineOffset; lineBreakIndex < 0 && i < length; ++i) {
        const char = buffer[i];
        if (char === ":" && fieldSepIndex < 0) {
          fieldSepIndex = i - position;
        } else if (char === "\r") {
          sawCarriageReturn = true;
          lineBreakIndex = i - position;
        } else if (char === "\n") {
          lineBreakIndex = i - position;
        }
      }

      // If a complete line is not found yet, store offset and exit
      if (lineBreakIndex < 0) {
        lineOffset = length - position;
        fieldOffset = fieldSepIndex;
        break;
      } else {
        lineOffset = 0;
        fieldOffset = -1;
      }

      // Parse the line
      parseLine(buffer, position, fieldSepIndex, lineBreakIndex);
      position += lineBreakIndex + 1;
    }

    // Trim the processed portion
    if (position === length) {
      buffer = "";
    } else if (position > 0) {
      buffer = buffer.slice(position);
    }
  }

  // Parse a single line from the stream
  function parseLine(
    str: string,
    start: number,
    sepIndex: number,
    lineLength: number,
  ) {
    // Empty line = dispatch event
    if (lineLength === 0) {
      if (dataBuffer.length > 0) {
        callback({
          type: "event",
          id: lastEventId,
          event: currentEvent || undefined,
          data: dataBuffer.slice(0, -1), // Remove trailing newline
        });
        dataBuffer = "";
        lastEventId = undefined;
      }
      currentEvent = undefined;
      return;
    }

    // Get field name
    const isNoColon = sepIndex < 0;
    const field = str.slice(start, start + (isNoColon ? lineLength : sepIndex));

    // Get value start and length
    let valueStart = 0;
    if (isNoColon) {
      valueStart = lineLength;
    } else {
      valueStart =
        str[start + sepIndex + 1] === " " ? sepIndex + 2 : sepIndex + 1;
    }
    const valueOffset = start + valueStart;
    const valueLength = lineLength - valueStart;
    const value = str.slice(valueOffset, valueOffset + valueLength).toString();

    // Assign field
    if (field === "data") {
      dataBuffer += value ? `${value}\n` : "\n";
    } else if (field === "event") {
      currentEvent = value;
    } else if (field === "id" && !value.includes("\0")) {
      lastEventId = value;
    } else if (field === "retry") {
      const retryMs = parseInt(value, 10);
      if (!Number.isNaN(retryMs)) {
        callback({
          type: "reconnect-interval",
          value: retryMs,
        });
      }
    }
  }

  // Return public methods
  return {
    feed,
    reset,
  };
}
