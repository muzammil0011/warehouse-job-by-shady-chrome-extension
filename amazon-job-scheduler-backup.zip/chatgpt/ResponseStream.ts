export class ResponseStream {
  onData?: (data: any, done: boolean, error?: any) => void;
}
