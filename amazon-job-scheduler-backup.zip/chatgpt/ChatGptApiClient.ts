import { ChatGPTBackend } from "./ChatGPTBackend";
import { getClientId } from "./getClientId";
import { GlobalClass } from "./global";
import { ResponseStream } from "./ResponseStream";
import { createEventStreamParser } from "./streamParser";
import { toByteArray } from "./toByteArray";
import { WebSocketMessageHandler } from "./WebSocketMessageHandler";

interface ChatService {
  updateConversation(conv: Conversation): void;
  getProofToken(seed: string, difficulty: number): Promise<string>;
}

interface Conversation {
  id: string;
  chatGptConvId?: string;
}

interface ChatItem {
  itemType: "question" | "reply";
  content: string;
}

interface Question {
  content: string;
  parentMessageId?: string;
  prevChatItems?: ChatItem[];
}

interface TaskDetails {
  taskId: string;
}

interface TaskInfo {
  taskId: string;
  convId: string;
  abortController: AbortController;
}

interface GetAnswerParams {
  taskId: string;
  conv: Conversation;
  question: Question;
}

interface HideConversationParams {
  chatGptConvId: string;
}

interface UpdateTitleParams {
  chatGptConvId: string;
  messageId: string;
}

interface FetchOptions {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  headers: Record<string, string>;
  data?: any;
  signal?: AbortSignal;
  ignoreAllCatch?: boolean;
  returnOriginResponse?: boolean;
  errorHandler?: (error: any) => any;
}

interface ChatRequirements {
  token: string;
  proofofwork: { seed: string; difficulty: number };
}

interface FetchCompletionsArgs {
  onMessage: (message: string) => void;
  taskInfo: TaskInfo;
  question: Question;
  messageId: string;
  token: string;
  chatGptConvId?: string;
}

const GC = new GlobalClass();

export class ChatGptApiClient {
  private baseUrl = "https://chatgpt.com/backend-api";
  private taskMap: Record<string, TaskInfo> = {};
  private modelNameMap: Record<string, string> = {};
  private defaultModelName?: string;
  private wsClient: WebSocketMessageHandler = new WebSocketMessageHandler();
  private responseMode?: string;
  private wsUrl: string = "";
  conversationMap: Record<string, Conversation> = {};
  creating: Promise<void> | null = null;

  constructor() {}

  // Get the access token from the current session
  async getToken() {
    try {
      const response = await fetch("https://chatgpt.com/api/auth/session");
      if (response.status === 403) throw "CLOUDFLARE";
      const data = await response.json();
      if (data.accessToken) return data.accessToken;
    } catch {
      throw "UNAUTHORIZED";
    }
    throw "UNAUTHORIZED";
  }

  // Cancel a task by aborting the request and removing from the map
  cancelTask(token: string, taskDetails: TaskDetails): void {
    const task = this.taskMap[taskDetails.taskId];
    if (task) {
      task.abortController.abort();
      delete this.taskMap[task.taskId];
    }
  }

  // Get an answer asynchronously, wrapping in a response handler
  async getAnswer(
    token: string,
    params: GetAnswerParams,
  ): Promise<ResponseStream> {
    const responseStream = new ResponseStream(); // likely an event-emitting stream
    const abortController = new AbortController();
    const taskInfo = {
      taskId: params.taskId,
      abortController,
      convId: params.conv.id,
    };

    this.doGetAnswer({ token, taskInfo, params, resp: responseStream }).catch(
      (err) => {
        responseStream.onData?.(null, true, err);
      },
    );

    return responseStream;
  }

  // Hide a conversation (mark as not visible)
  async hideConversation(
    token: string,
    params: HideConversationParams,
  ): Promise<void> {
    const conversationId = params.chatGptConvId;
    await this.fetch({
      path: `${this.baseUrl}/conversation/${conversationId}`,
      method: "PATCH",
      headers: this.getRequestHeader(token),
      data: { isVisible: false },
    });
  }

  async updateConversation(conv: Conversation): Promise<void> {
    this.conversationMap[conv.id] = conv;
    // await this.saveConversations();
  }

  // Internal method to handle getting an answer via WebSocket or HTTP
  async doGetAnswer({
    token,
    taskInfo,
    params,
    resp,
  }: {
    token: string;
    taskInfo: TaskInfo;
    params: GetAnswerParams;
    resp: ResponseStream;
  }): Promise<void> {
    const { conv, question } = params;
    this.taskMap[taskInfo.taskId] = taskInfo;

    let finalAnswer: any = null;
    const messageId = GC.genId(); // generate a new message ID

    if (!this.responseMode) {
      this.responseMode = await new ChatGPTBackend(token)
        .getResponseMode()
        .catch(() => {
          throw "CLOUDFLARE";
        });
    }

    let replyCount =
      question.prevChatItems?.filter((item) => item.itemType === "reply")
        .length || 0;
    if (this.responseMode === "websocket") replyCount = 0;

    await this.fetchCompletions({
      question: question,
      chatGptConvId: conv.chatGptConvId,
      messageId,
      token,
      taskInfo,
      onMessage: (message: any) => {
        if (message === "[DONE]") {
          resp.onData?.(finalAnswer, true);
          this.cancelTask(token, { taskId: taskInfo.taskId });
          return;
        }

        try {
          const data = JSON.parse(message);

          if (!conv.chatGptConvId && data.conversation_id) {
            conv.chatGptConvId = data.conversation_id;
            this.updateConversation(conv);
          }

          if (data.error) {
            resp.onData?.(null, true, data.error);
            return;
          }

          if (data.message?.author?.role !== "assistant") return;

          if (replyCount > 0) {
            replyCount--;
            return;
          }

          const content = data.message?.content?.parts?.[0];
          if (content) {
            finalAnswer = {
              content,
              parentMessageId: messageId,
              type: "answer",
              messageId: data.message.id,
              convId: conv.id,
            };
            resp.onData?.(
              finalAnswer,
              data.message?.status === "finished_successfully",
            );
          }
        } catch (err) {
          console.log("unsupported streaming msg:", err);
        }
      },
    });
  }

  // Get the default model name, with fallback
  async getModelName(token: string) {
    if (!this.defaultModelName) {
      try {
        const models = await this.fetchModels(token);
        this.defaultModelName = models[0].slug;
      } catch (err) {
        console.log({ err });
        return "text-davinci-002-render-sha";
      }
    }
    return this.defaultModelName;
  }

  // Return headers for authenticated requests
  getRequestHeader(token: string) {
    return {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };
  }

  async hasOffscreenDocument(url: string): Promise<boolean> {
    const runtime = chrome.runtime;

    if ("getContexts" in runtime) {
      const contexts = await (runtime.getContexts as any)({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
        documentUrls: [url],
      });
      return contexts.length > 0;
    }

    const swGlobal = globalThis as any;

    if (
      "clients" in swGlobal &&
      typeof swGlobal.clients.matchAll === "function"
    ) {
      const clients = await swGlobal.clients.matchAll();
      return clients.some((client: any) => client.url === url);
    }

    return false;
  }

  async getProofToken(param1: string, param2: string): Promise<string> {
    let token = "";
    try {
      const url = "arkose-frame.html";

      if (!(await this.hasOffscreenDocument(chrome.runtime.getURL(url)))) {
        if (!this.creating) {
          this.creating = chrome.offscreen.createDocument({
            url,
            reasons: [chrome.offscreen.Reason.IFRAME_SCRIPTING],
            justification: "Generating proof token using offscreen script",
          });
        }
        await this.creating;
        this.creating = null;
      }

      token = await chrome.runtime.sendMessage({
        type: "getProofToken",
        target: "offscreen",
        params: [param1, param2],
      });
    } catch (err) {
      console.error("Failed to get proof token:", err);
    }

    return token;
  }

  // Handle message streaming and WebSocket setup
  async fetchCompletions({
    onMessage,
    taskInfo,
    question,
    messageId,
    token,
    chatGptConvId,
  }: FetchCompletionsArgs): Promise<void> {
    const model = await this.getModelName(token);
    const signal = taskInfo.abortController.signal;
    if (signal.aborted) return;

    const previousItems = question.prevChatItems || [];
    const parser = createEventStreamParser((event) => {
      if (event.type === "event") onMessage(event.data);
    });

    let arkoseToken = undefined;

    console.log("I am here now yo yo", this.responseMode);
    if (this.responseMode === "websocket") {
      const modeClient = new ChatGPTBackend(token);
      if (!this.wsUrl) this.wsUrl = await modeClient.getWebsocketUrl();
      this.wsClient.connect(this.wsUrl, {
        onServerData: (packet) => {
          const decoded = new TextDecoder().decode(toByteArray(packet.body));
          parser.feed(decoded);
        },
      });
    }

    const clientId = await getClientId();

    const chatRequirements = await this.fetch({
      method: "POST",
      path: `${this.baseUrl}/sentinel/chat-requirements`,
      headers: {
        ...this.getRequestHeader(token),
        "oai-device-id": clientId,
      },
      data: {
        conversationMode: { kind: "primary_assistant" },
      },
    });

    const proofToken = await this.getProofToken(
      chatRequirements.proofofwork.seed,
      chatRequirements.proofofwork.difficulty,
    );

    const response = await this.fetch({
      method: "POST",
      path: `${this.baseUrl}/conversation`,
      headers: {
        ...this.getRequestHeader(token),
        "openai-sentinel-proof-token": proofToken,
        "openai-sentinel-chat-requirements-token": chatRequirements.token,
        "oai-device-id": clientId,
      },
      returnOriginResponse: true,
      signal,
      data: {
        action: "next",
        messages: [
          ...previousItems.map((item) => ({
            id: GC.genId(),
            author: {
              role: item.itemType === "question" ? "user" : "assistant",
            },
            content: {
              contentType: "text",
              parts: [item.content],
            },
          })),
          {
            id: messageId,
            author: { role: "user" },
            content: {
              contentType: "text",
              parts: [question.content],
            },
          },
        ],
        conversationMode: { kind: "primary_assistant" },
        conversationId: chatGptConvId,
        model,
        parentMessageId: question.parentMessageId || GC.genId(),
        arkoseToken,
        suggestions: [],
      },
      ignoreAllCatch: true,
    });

    if (!response.ok) {
      const errorBody = await response.json().catch(() => {
        throw `UNKNOWN_OPENAI_ERROR: ${response.status} ${response.statusText}`;
      });
      throw this.openApiErrorHandler(errorBody);
    }

    if (this.responseMode === "websocket") return;

    const reader = response.body.getReader();
    try {
      while (!signal.aborted) {
        const { done, value } = await reader.read();
        if (done) return;
        const chunk = new TextDecoder().decode(value);
        parser.feed(chunk);
      }
    } catch {
      reader.releaseLock();
    }
  }

  // Generic fetch wrapper with error handling and formatting
  async fetch<T = any>(options: FetchOptions): Promise<T | Response> {
    const body = GC.underlize(options.data);
    const response = await fetch(options.path, {
      method: options.method,
      headers: options.headers,
      body: body ? JSON.stringify(body) : undefined,
      signal: options.signal,
    });

    if (response.status === 401) throw "CLOUDFLARE";
    if (response.status === 403) {
      try {
        const errorData = await response.json();
        throw typeof errorData?.detail === "string"
          ? errorData.detail
          : "CLOUDFLARE";
      } catch (err) {
        console.log({ err });
        throw options.ignoreAllCatch ? err : "CLOUDFLARE";
      }
    }

    if (options.returnOriginResponse) return response;

    if (response.ok) {
      const json = await response.json();
      return GC.camelize(json);
    }

    const errorJson = await response.json().catch(() => {
      throw `UNKNOWN_OPENAI_ERROR: ${response.status} ${response.statusText}`;
    });

    throw options.errorHandler
      ? options.errorHandler(errorJson)
      : this.openApiErrorHandler(errorJson);
  }

  // Handle and translate API error responses into common keywords
  openApiErrorHandler(error: any): string {
    let message = "",
      code = "";
    if (error?.detail) {
      if (typeof error.detail === "string") {
        message = error.detail;
      } else if (error.detail.message) {
        message = error.detail.message;
        code = error.detail.code;
      }
    }

    if (message.includes("Too many requests")) return "TOO_MANY_REQUESTS";
    if (code === "challenge_required") return "CLOUDFLARE";
    if (
      message.includes("Unauthorized") ||
      message.includes("expired") ||
      code === "invalid_jwt"
    )
      return "UNAUTHORIZED";
    if (message.includes("Not Found")) return "OPENAI_NOT_FOUND";

    return message || "UNKNOWN";
  }

  // Generate a title for a conversation
  async updateTitle(
    token: string,
    { chatGptConvId, messageId }: UpdateTitleParams,
  ): Promise<any> {
    return await this.fetch({
      method: "POST",
      path: `${this.baseUrl}/conversation/gen_title/${chatGptConvId}`,
      headers: this.getRequestHeader(token),
      data: {
        message_id: messageId,
        model: await this.getModelName(token),
      },
    });
  }

  // Fetch available models
  async fetchModels(token: string) {
    const response = await this.fetch({
      method: "GET",
      path: `${this.baseUrl}/models`,
      headers: this.getRequestHeader(token),
    });

    return response.models;
  }
}

// const client = new ChatGptApiClient();
// const token = await client.getToken();
// const answer = await client.getAnswer(token, {
//   taskId: "b6e7e2c1-42f6-4f1e-9e0b-8de349c34010",
//   conv: {
//     id: "b6e7e2c1-42f6-4f1e-9e0b-8de349c34011",
//     chatGptConvId: "b6e7e2c1-42f6-4f1e-9e0b-8de349c34022",
//   },
//   question: {
//     content: "Hi",
//   },
// });
// console.log(answer);
