type HTTPMethod = "GET" | "POST" | "PUT" | "DELETE" | "PATCH";

interface Model {
  slug: string;
  max_tokens: number;
  title: string;
}

interface ModelsResponse {
  models: Model[];
}

interface WebsocketRegistration {
  wss_url: string;
}

export class ChatGPTBackend {
  private token: string;

  constructor(token: string) {
    this.token = token;
  }

  async requestBackendAPIWithToken(
    method: HTTPMethod,
    endpoint: string,
    body?: Record<string, any>,
  ): Promise<Response> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`;
    }

    const response = await fetch(`https://chatgpt.com/backend-api${endpoint}`, {
      method: method,
      headers: headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });

    return response;
  }

  async getModels(): Promise<Model[]> {
    const response = await this.requestBackendAPIWithToken("GET", "/models");
    const data: ModelsResponse = await response.json();
    return data.models;
  }

  async generateChatTitle(
    conversationId: string,
    messageId: string,
  ): Promise<void> {
    await this.requestBackendAPIWithToken(
      "POST",
      `/conversation/gen_title/${conversationId}`,
      {
        message_id: messageId,
      },
    );
  }

  async getWebsocketUrl(): Promise<string> {
    const registration = await this.registerWebsocket();
    return registration.wss_url;
  }

  async getResponseMode(): Promise<"websocket" | "sse"> {
    const features = await this.getUserFeatures();
    console.log({ features });
    return features.includes("shared_websocket") ? "websocket" : "sse";
  }

  async registerWebsocket(): Promise<WebsocketRegistration> {
    const response = await this.requestBackendAPIWithToken(
      "POST",
      "/register-websocket",
    );
    return await response.json();
  }

  async getUserFeatures(): Promise<string[]> {
    const response = await this.requestBackendAPIWithToken(
      "GET",
      "/accounts/check/v4-2023-04-27",
    );
    const data = await response.json();
    return this.extractNested(data, "accounts.default.features", []);
  }
  private extractNested(
    obj: Record<string, any>,
    path: string,
    fallback: any,
  ): any {
    return path.split(".").reduce((acc, key) => acc?.[key], obj) ?? fallback;
  }
}
