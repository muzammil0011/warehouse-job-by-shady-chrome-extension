import { v4 as uuidv4 } from "uuid";

export class GlobalClass {
  getExtensionVersion(): string {
    return chrome.runtime.getManifest().version;
  }

  listToMap<T, K extends keyof T>(
    arr: T[],
    key: K | ((item: T) => string),
  ): Record<string, T> {
    const isFn = typeof key === "function";
    return arr.reduce((map: Record<string, T>, item: T) => {
      const k = isFn ? (key as Function)(item) : item[key as K];
      map[k as string] = item;
      return map;
    }, {});
  }

  async tryGetTab(tabId: string): Promise<chrome.tabs.Tab | null> {
    try {
      return await chrome.tabs.get(parseInt(tabId));
    } catch {
      return null;
    }
  }

  getOsType(): string {
    const ua = navigator.userAgent;
    const platform =
      (navigator as any).userAgentData?.platform || navigator.platform;
    const mac = ["Macintosh", "MacIntel", "MacPPC", "Mac68K", "macOS"];
    const win = ["Win32", "Win64", "Windows", "WinCE"];
    const ios = ["iPhone", "iPad", "iPod"];

    if (mac.includes(platform)) return "OSX";
    if (ios.includes(platform)) return "IOS";
    if (win.includes(platform)) return "Windows";
    if (/Android/.test(ua)) return "Android";
    if (/Linux/.test(platform)) return "Linux";

    console.error(
      "unable to detect os type, use Windows as default",
      platform,
      ua,
    );
    return "Windows";
  }

  detectSystemColorScheme(): "dark" | "light" {
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  }

  isPromise(obj: any): obj is Promise<any> {
    return (
      !!obj &&
      (typeof obj === "object" || typeof obj === "function") &&
      typeof obj.then === "function"
    );
  }

  getWebOrigin(): string {
    return "https://webapp.chatgpt4google.com";
  }

  getModKeyName(prependCtrl = false): string {
    return this.getOsType() === "OSX" ? "⌘" : prependCtrl ? "Ctrl + " : "Ctrl";
  }

  getStaticFile(file: string): string {
    return chrome.runtime.getURL(`static/${file}`);
  }

  genId(): string {
    return uuidv4();
  }

  onDOMReady(callback: () => void): void {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", callback);
    } else {
      callback();
    }
  }

  getRootId(id: string): string {
    return `chatgpt-${id}`;
  }

  camelizeKey(key: string, delimiters: string[] = ["-", "_"]): string {
    const result: string[] = [];
    let i = 0;
    const delims = new Set(delimiters);

    while (i < key.length) {
      if (delims.has(key[i])) {
        result.push(key[++i]?.toUpperCase() || "");
      } else {
        result.push(key[i]);
      }
      i++;
    }
    return result.join("");
  }

  camelize(input: any): any {
    if (input == null) return null;
    if (Array.isArray(input)) return input.map((item) => this.camelize(item));
    if (typeof input === "object") {
      const result: Record<string, any> = {};
      for (const key in input) {
        result[this.camelizeKey(key)] = this.camelize(input[key]);
      }
      return result;
    }
    return input;
  }

  underlizeKey(key: string, preserveFirst = false): string {
    const result: string[] = [];
    const lower = key.toLowerCase();

    for (let i = 0; i < key.length; i++) {
      if (key[i] !== lower[i] && (!preserveFirst || i !== 0)) {
        result.push("_", lower[i]);
      } else {
        result.push(lower[i]);
      }
    }
    return result.join("");
  }

  underlize(input: any): any {
    if (input == null) return null;
    if (Array.isArray(input)) return input.map((item) => this.underlize(item));
    if (typeof input === "object") {
      const result: Record<string, any> = {};
      for (const key in input) {
        const newKey = this.underlizeKey(key);
        const value = this.underlize(input[key]);
        if (value != null) result[newKey] = value;
      }
      return result;
    }
    return input;
  }

  capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  async *streamAsyncIterable(
    stream: ReadableStream<Uint8Array>,
  ): AsyncGenerator<Uint8Array> {
    const reader = stream.getReader();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) return;
        yield value;
      }
    } finally {
      reader.releaseLock();
    }
  }

  async isBraveBrowser(): Promise<boolean | undefined> {
    try {
      return await (navigator as any).brave?.isBrave();
    } catch (err) {
      console.error("Error detecting Brave browser:", err);
      return undefined;
    }
  }

  endsWithQuestionMark(str: string): boolean {
    return /[\?？⸮]$/.test(str);
  }

  copyToClipboard(text: string): void {
    const textarea = document.createElement("textarea");
    textarea.id = "copy-to-clipboard";
    document.body.appendChild(textarea);
    textarea.value = text;
    textarea.select();
    document.execCommand("copy");
    document.body.removeChild(textarea);
  }

  getOffsetOfPageTop(el: Element): number {
    return (
      document.documentElement.clientHeight -
      (el.getBoundingClientRect().top -
        document.documentElement.getBoundingClientRect().top)
    );
  }

  async delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async getContentFromClipboard(): Promise<string> {
    try {
      const text = await navigator.clipboard.readText();
      await chrome.tabs.query({});
      return text;
    } catch {
      return "";
    }
  }

  formatMonicaSdkError(error: any): string {
    let message = error.message || error.data?.message;
    if (!message && typeof error === "string") message = error;
    if (!message && error?.code) message = `server error (${error.code})`;
    if (!message) message = "server error";
    return message.replace(
      /\u8bf7\u6c42\u5931\u8d25\((\d+)\)/,
      "server error($1)",
    );
  }

  getErrorMsg(error: any, fallback?: string): string | undefined {
    if (typeof error === "undefined" || typeof error === "string") return error;
    if (typeof error === "object") {
      return error?.msg || error?.message;
    }
    return fallback;
  }

  addPromptLangControl(prompt: string, lang: string): string {
    return lang === "auto" ? prompt : `(Answer in ${lang})\n${prompt}`;
  }

  getProductName(): string {
    return "ChatGPT for Google";
  }
}
