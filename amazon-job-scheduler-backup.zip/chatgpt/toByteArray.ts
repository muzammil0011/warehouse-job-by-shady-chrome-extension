const base64CharMap: Record<number, number> = (() => {
  const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const map: Record<number, number> = {};
  for (let i = 0; i < chars.length; i++) {
    map[chars.charCodeAt(i)] = i;
  }
  return map;
})();

function getDecodedLength(base64: string): [number, number] {
  let len = base64.length;
  let padding = 0;

  if (base64.endsWith("==")) padding = 2;
  else if (base64.endsWith("=")) padding = 1;

  return [len, padding];
}

function allocateByteArray(
  base64: string,
  mainLength: number,
  padding: number,
): number {
  return (mainLength * 3) / 4 - padding;
}

const ByteArray = Uint8Array;

export function toByteArray(input: string): Uint8Array {
  const [mainLength, paddingLength] = getDecodedLength(input); // e.g., [length without padding, padding count]
  const byteArray = new ByteArray(
    allocateByteArray(input, mainLength, paddingLength),
  );

  let byteIndex = 0;
  const decodeLength = paddingLength > 0 ? mainLength - 4 : mainLength;

  let buffer: number;

  for (let i = 0; i < decodeLength; i += 4) {
    buffer =
      (base64CharMap[input.charCodeAt(i)] << 18) |
      (base64CharMap[input.charCodeAt(i + 1)] << 12) |
      (base64CharMap[input.charCodeAt(i + 2)] << 6) |
      base64CharMap[input.charCodeAt(i + 3)];

    byteArray[byteIndex++] = (buffer >> 16) & 0xff;
    byteArray[byteIndex++] = (buffer >> 8) & 0xff;
    byteArray[byteIndex++] = buffer & 0xff;
  }

  // Handle padding cases
  if (paddingLength === 2) {
    buffer =
      (base64CharMap[input.charCodeAt(decodeLength)] << 2) |
      (base64CharMap[input.charCodeAt(decodeLength + 1)] >> 4);

    byteArray[byteIndex++] = buffer & 0xff;
  } else if (paddingLength === 1) {
    buffer =
      (base64CharMap[input.charCodeAt(decodeLength)] << 10) |
      (base64CharMap[input.charCodeAt(decodeLength + 1)] << 4) |
      (base64CharMap[input.charCodeAt(decodeLength + 2)] >> 2);

    byteArray[byteIndex++] = (buffer >> 8) & 0xff;
    byteArray[byteIndex++] = buffer & 0xff;
  }

  return byteArray;
}
