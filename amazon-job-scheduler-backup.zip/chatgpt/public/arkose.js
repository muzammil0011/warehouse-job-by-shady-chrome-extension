"use strict";
(() => {
  var Ke = Object.create;
  var Ge = Object.defineProperty;
  var Qe = Object.getOwnPropertyDescriptor;
  var Xe = Object.getOwnPropertyNames;
  var er = Object.getPrototypeOf,
    rr = Object.prototype.hasOwnProperty;
  var sr = (A, d) => () => (
    d || A((d = { exports: {} }).exports, d), d.exports
  );
  var nr = (A, d, E, _) => {
    if ((d && typeof d == "object") || typeof d == "function")
      for (let x of Xe(d))
        !rr.call(A, x) &&
          x !== E &&
          Ge(A, x, {
            get: () => d[x],
            enumerable: !(_ = Qe(d, x)) || _.enumerable,
          });
    return A;
  };
  var Ye = (A, d, E) => (
    (E = A != null ? Ke(er(A)) : {}),
    nr(
      d || !A || !A.__esModule
        ? Ge(E, "default", { value: A, enumerable: !0 })
        : E,
      A,
    )
  );
  var Ze = sr(() => {
    "use strict";
    globalThis &&
      (globalThis.__c4g_envvars__ = {
        dev: !1,
        prod: !0,
        host: "https://webapp.chatgpt4google.com",
        browser: "chrome",
      });
  });
  var tr = Ye(Ze(), 1);
  (function () {
    "use strict";
    function A(e, n, r) {
      (this.blocks = []),
        (this.s = []),
        (this.padding = n),
        (this.outputBits = r),
        (this.reset = !0),
        (this.finalized = !1),
        (this.block = 0),
        (this.start = 0),
        (this.blockCount = (1600 - (e << 1)) >> 5),
        (this.byteCount = this.blockCount << 2),
        (this.outputBlocks = r >> 5),
        (this.extraBytes = (31 & r) >> 3);
      for (var s = 0; s < 50; ++s) this.s[s] = 0;
    }
    function d(e, n, r) {
      A.call(this, e, n, r);
    }
    var E = "input is invalid type",
      _ = typeof window == "object",
      x = _ ? window : {};
    x.JS_SHA3_NO_WINDOW && (_ = !1);
    var ze = !_ && typeof self == "object";
    !x.JS_SHA3_NO_NODE_JS &&
    typeof process == "object" &&
    process.versions &&
    process.versions.node
      ? (x = global)
      : ze && (x = self);
    for (
      var Je =
          !x.JS_SHA3_NO_COMMON_JS &&
          typeof module == "object" &&
          module.exports,
        Ve = typeof define == "function" && define.amd,
        U = !x.JS_SHA3_NO_ARRAY_BUFFER && typeof ArrayBuffer < "u",
        h = "0123456789abcdef".split(""),
        z = [4, 1024, 262144, 67108864],
        v = [0, 8, 16, 24],
        R = [
          1, 0, 32898, 0, 32906, 2147483648, 2147516416, 2147483648, 32907, 0,
          2147483649, 0, 2147516545, 2147483648, 32777, 2147483648, 138, 0, 136,
          0, 2147516425, 0, 2147483658, 0, 2147516555, 0, 139, 2147483648,
          32905, 2147483648, 32771, 2147483648, 32770, 2147483648, 128,
          2147483648, 32778, 0, 2147483658, 2147483648, 2147516545, 2147483648,
          32896, 2147483648, 2147483649, 0, 2147516424, 2147483648,
        ],
        V = [224, 256, 384, 512],
        D = [128, 256],
        H = ["hex", "buffer", "arrayBuffer", "array", "digest"],
        Z = { 128: 168, 256: 136 },
        He =
          x.JS_SHA3_NO_NODE_JS || !Array.isArray
            ? function (e) {
                return Object.prototype.toString.call(e) === "[object Array]";
              }
            : Array.isArray,
        g =
          !U || (!x.JS_SHA3_NO_ARRAY_BUFFER_IS_VIEW && ArrayBuffer.isView)
            ? ArrayBuffer.isView
            : function (e) {
                return (
                  typeof e == "object" &&
                  e.buffer &&
                  e.buffer.constructor === ArrayBuffer
                );
              },
        l = function (e) {
          var n = typeof e;
          if (n === "string") return [e, !0];
          if (n !== "object" || e === null) throw new Error(E);
          if (U && e.constructor === ArrayBuffer)
            return [new Uint8Array(e), !1];
          if (!He(e) && !g(e)) throw new Error(E);
          return [e, !1];
        },
        u = function (e) {
          return l(e)[0].length === 0;
        },
        p = function (e) {
          for (var n = [], r = 0; r < e.length; ++r) n[r] = e[r];
          return n;
        },
        y = function (e, n, r) {
          return function (s) {
            return new A(e, n, e).update(s)[r]();
          };
        },
        S = function (e, n, r) {
          return function (s, i) {
            return new A(e, n, i).update(s)[r]();
          };
        },
        M = function (e, n, r) {
          return function (s, i, a, o) {
            return B[`cshake${e}`].update(s, i, a, o)[r]();
          };
        },
        W = function (e, n, r) {
          return function (s, i, a, o) {
            return B[`kmac${e}`].update(s, i, a, o)[r]();
          };
        },
        I = function (e, n, r, s) {
          for (var i = 0; i < H.length; ++i) {
            var a = H[i];
            e[a] = n(r, s, a);
          }
          return e;
        },
        q = function (e, n) {
          var r = y(e, n, "hex");
          return (
            (r.create = function () {
              return new A(e, n, e);
            }),
            (r.update = function (s) {
              return r.create().update(s);
            }),
            I(r, y, e, n)
          );
        },
        $ = [
          {
            name: "keccak",
            padding: [1, 256, 65536, 16777216],
            bits: V,
            createMethod: q,
          },
          {
            name: "sha3",
            padding: [6, 1536, 393216, 100663296],
            bits: V,
            createMethod: q,
          },
          {
            name: "shake",
            padding: [31, 7936, 2031616, 520093696],
            bits: D,
            createMethod(e, n) {
              var r = S(e, n, "hex");
              return (
                (r.create = function (s) {
                  return new A(e, n, s);
                }),
                (r.update = function (s, i) {
                  return r.create(i).update(s);
                }),
                I(r, S, e, n)
              );
            },
          },
          {
            name: "cshake",
            padding: z,
            bits: D,
            createMethod(e, n) {
              var r = Z[e],
                s = M(e, 0, "hex");
              return (
                (s.create = function (i, a, o) {
                  return u(a) && u(o)
                    ? B[`shake${e}`].create(i)
                    : new A(e, n, i).bytepad([a, o], r);
                }),
                (s.update = function (i, a, o, m) {
                  return s.create(a, o, m).update(i);
                }),
                I(s, M, e, n)
              );
            },
          },
          {
            name: "kmac",
            padding: z,
            bits: D,
            createMethod(e, n) {
              var r = Z[e],
                s = W(e, 0, "hex");
              return (
                (s.create = function (i, a, o) {
                  return new d(e, n, a).bytepad(["KMAC", o], r).bytepad([i], r);
                }),
                (s.update = function (i, a, o, m) {
                  return s.create(i, o, m).update(a);
                }),
                I(s, W, e, n)
              );
            },
          },
        ],
        B = {},
        T = [],
        w = 0;
      w < $.length;
      ++w
    )
      for (var P = $[w], j = P.bits, F = 0; F < j.length; ++F) {
        var L = `${P.name}_${j[F]}`;
        if (
          (T.push(L),
          (B[L] = P.createMethod(j[F], P.padding)),
          P.name !== "sha3")
        ) {
          var J = P.name + j[F];
          T.push(J), (B[J] = B[L]);
        }
      }
    (A.prototype.update = function (e) {
      if (this.finalized) throw new Error("finalize already called");
      var n = l(e);
      e = n[0];
      for (
        var r,
          s,
          i = n[1],
          a = this.blocks,
          o = this.byteCount,
          m = e.length,
          c = this.blockCount,
          t = 0,
          b = this.s;
        t < m;

      ) {
        if (this.reset)
          for (this.reset = !1, a[0] = this.block, r = 1; r < c + 1; ++r)
            a[r] = 0;
        if (i)
          for (r = this.start; t < m && r < o; ++t)
            (s = e.charCodeAt(t)) < 128
              ? (a[r >> 2] |= s << v[3 & r++])
              : s < 2048
                ? ((a[r >> 2] |= (192 | (s >> 6)) << v[3 & r++]),
                  (a[r >> 2] |= (128 | (63 & s)) << v[3 & r++]))
                : s < 55296 || s >= 57344
                  ? ((a[r >> 2] |= (224 | (s >> 12)) << v[3 & r++]),
                    (a[r >> 2] |= (128 | ((s >> 6) & 63)) << v[3 & r++]),
                    (a[r >> 2] |= (128 | (63 & s)) << v[3 & r++]))
                  : ((s =
                      65536 +
                      (((1023 & s) << 10) | (1023 & e.charCodeAt(++t)))),
                    (a[r >> 2] |= (240 | (s >> 18)) << v[3 & r++]),
                    (a[r >> 2] |= (128 | ((s >> 12) & 63)) << v[3 & r++]),
                    (a[r >> 2] |= (128 | ((s >> 6) & 63)) << v[3 & r++]),
                    (a[r >> 2] |= (128 | (63 & s)) << v[3 & r++]));
        else
          for (r = this.start; t < m && r < o; ++t)
            a[r >> 2] |= e[t] << v[3 & r++];
        if (((this.lastByteIndex = r), r >= o)) {
          for (this.start = r - o, this.block = a[c], r = 0; r < c; ++r)
            b[r] ^= a[r];
          O(b), (this.reset = !0);
        } else this.start = r;
      }
      return this;
    }),
      (A.prototype.encode = function (e, n) {
        var r = 255 & e,
          s = 1,
          i = [r];
        for (r = 255 & (e >>= 8); r > 0; )
          i.unshift(r), (r = 255 & (e >>= 8)), ++s;
        return n ? i.push(s) : i.unshift(s), this.update(i), i.length;
      }),
      (A.prototype.encodeString = function (e) {
        var n = l(e);
        e = n[0];
        var r = n[1],
          s = 0,
          i = e.length;
        if (r)
          for (var a = 0; a < e.length; ++a) {
            var o = e.charCodeAt(a);
            o < 128
              ? (s += 1)
              : o < 2048
                ? (s += 2)
                : o < 55296 || o >= 57344
                  ? (s += 3)
                  : ((o =
                      65536 +
                      (((1023 & o) << 10) | (1023 & e.charCodeAt(++a)))),
                    (s += 4));
          }
        else s = i;
        return (s += this.encode(8 * s)), this.update(e), s;
      }),
      (A.prototype.bytepad = function (e, n) {
        for (var r = this.encode(n), s = 0; s < e.length; ++s)
          r += this.encodeString(e[s]);
        var i = (n - (r % n)) % n,
          a = [];
        return (a.length = i), this.update(a), this;
      }),
      (A.prototype.finalize = function () {
        if (!this.finalized) {
          this.finalized = !0;
          var e = this.blocks,
            n = this.lastByteIndex,
            r = this.blockCount,
            s = this.s;
          if (
            ((e[n >> 2] |= this.padding[3 & n]),
            this.lastByteIndex === this.byteCount)
          )
            for (e[0] = e[r], n = 1; n < r + 1; ++n) e[n] = 0;
          for (e[r - 1] |= 2147483648, n = 0; n < r; ++n) s[n] ^= e[n];
          O(s);
        }
      }),
      (A.prototype.toString = A.prototype.hex =
        function () {
          this.finalize();
          for (
            var e,
              n = this.blockCount,
              r = this.s,
              s = this.outputBlocks,
              i = this.extraBytes,
              a = 0,
              o = 0,
              m = "";
            o < s;

          ) {
            for (a = 0; a < n && o < s; ++a, ++o)
              (e = r[a]),
                (m +=
                  h[(e >> 4) & 15] +
                  h[15 & e] +
                  h[(e >> 12) & 15] +
                  h[(e >> 8) & 15] +
                  h[(e >> 20) & 15] +
                  h[(e >> 16) & 15] +
                  h[(e >> 28) & 15] +
                  h[(e >> 24) & 15]);
            o % n == 0 && ((r = p(r)), O(r), (a = 0));
          }
          return (
            i &&
              ((e = r[a]),
              (m += h[(e >> 4) & 15] + h[15 & e]),
              i > 1 && (m += h[(e >> 12) & 15] + h[(e >> 8) & 15]),
              i > 2 && (m += h[(e >> 20) & 15] + h[(e >> 16) & 15])),
            m
          );
        }),
      (A.prototype.arrayBuffer = function () {
        this.finalize();
        var e,
          n = this.blockCount,
          r = this.s,
          s = this.outputBlocks,
          i = this.extraBytes,
          a = 0,
          o = 0,
          m = this.outputBits >> 3;
        e = i ? new ArrayBuffer((s + 1) << 2) : new ArrayBuffer(m);
        for (var c = new Uint32Array(e); o < s; ) {
          for (a = 0; a < n && o < s; ++a, ++o) c[o] = r[a];
          o % n == 0 && ((r = p(r)), O(r));
        }
        return i && ((c[o] = r[a]), (e = e.slice(0, m))), e;
      }),
      (A.prototype.buffer = A.prototype.arrayBuffer),
      (A.prototype.digest = A.prototype.array =
        function () {
          this.finalize();
          for (
            var e,
              n,
              r = this.blockCount,
              s = this.s,
              i = this.outputBlocks,
              a = this.extraBytes,
              o = 0,
              m = 0,
              c = [];
            m < i;

          ) {
            for (o = 0; o < r && m < i; ++o, ++m)
              (e = m << 2),
                (n = s[o]),
                (c[e] = 255 & n),
                (c[e + 1] = (n >> 8) & 255),
                (c[e + 2] = (n >> 16) & 255),
                (c[e + 3] = (n >> 24) & 255);
            m % r == 0 && ((s = p(s)), O(s));
          }
          return (
            a &&
              ((e = m << 2),
              (n = s[o]),
              (c[e] = 255 & n),
              a > 1 && (c[e + 1] = (n >> 8) & 255),
              a > 2 && (c[e + 2] = (n >> 16) & 255)),
            c
          );
        }),
      ((d.prototype = new A()).finalize = function () {
        return (
          this.encode(this.outputBits, !0), A.prototype.finalize.call(this)
        );
      });
    var O = function (e) {
      var n,
        r,
        s,
        i,
        a,
        o,
        m,
        c,
        t,
        b,
        f,
        k,
        C,
        N,
        G,
        Y,
        K,
        Q,
        X,
        ee,
        re,
        se,
        ne,
        ae,
        ie,
        oe,
        te,
        ge,
        me,
        Ae,
        le,
        ce,
        ue,
        fe,
        de,
        xe,
        he,
        pe,
        be,
        ye,
        ve,
        we,
        ke,
        Ce,
        Se,
        Pe,
        Ee,
        Be,
        _e,
        Te,
        je,
        Oe,
        Ne,
        $e,
        Fe,
        Re,
        Me,
        Ie,
        Le,
        Ue,
        De,
        We,
        qe;
      for (s = 0; s < 48; s += 2)
        (i = e[0] ^ e[10] ^ e[20] ^ e[30] ^ e[40]),
          (a = e[1] ^ e[11] ^ e[21] ^ e[31] ^ e[41]),
          (o = e[2] ^ e[12] ^ e[22] ^ e[32] ^ e[42]),
          (m = e[3] ^ e[13] ^ e[23] ^ e[33] ^ e[43]),
          (c = e[4] ^ e[14] ^ e[24] ^ e[34] ^ e[44]),
          (t = e[5] ^ e[15] ^ e[25] ^ e[35] ^ e[45]),
          (b = e[6] ^ e[16] ^ e[26] ^ e[36] ^ e[46]),
          (f = e[7] ^ e[17] ^ e[27] ^ e[37] ^ e[47]),
          (n =
            (k = e[8] ^ e[18] ^ e[28] ^ e[38] ^ e[48]) ^
            ((o << 1) | (m >>> 31))),
          (r =
            (C = e[9] ^ e[19] ^ e[29] ^ e[39] ^ e[49]) ^
            ((m << 1) | (o >>> 31))),
          (e[0] ^= n),
          (e[1] ^= r),
          (e[10] ^= n),
          (e[11] ^= r),
          (e[20] ^= n),
          (e[21] ^= r),
          (e[30] ^= n),
          (e[31] ^= r),
          (e[40] ^= n),
          (e[41] ^= r),
          (n = i ^ ((c << 1) | (t >>> 31))),
          (r = a ^ ((t << 1) | (c >>> 31))),
          (e[2] ^= n),
          (e[3] ^= r),
          (e[12] ^= n),
          (e[13] ^= r),
          (e[22] ^= n),
          (e[23] ^= r),
          (e[32] ^= n),
          (e[33] ^= r),
          (e[42] ^= n),
          (e[43] ^= r),
          (n = o ^ ((b << 1) | (f >>> 31))),
          (r = m ^ ((f << 1) | (b >>> 31))),
          (e[4] ^= n),
          (e[5] ^= r),
          (e[14] ^= n),
          (e[15] ^= r),
          (e[24] ^= n),
          (e[25] ^= r),
          (e[34] ^= n),
          (e[35] ^= r),
          (e[44] ^= n),
          (e[45] ^= r),
          (n = c ^ ((k << 1) | (C >>> 31))),
          (r = t ^ ((C << 1) | (k >>> 31))),
          (e[6] ^= n),
          (e[7] ^= r),
          (e[16] ^= n),
          (e[17] ^= r),
          (e[26] ^= n),
          (e[27] ^= r),
          (e[36] ^= n),
          (e[37] ^= r),
          (e[46] ^= n),
          (e[47] ^= r),
          (n = b ^ ((i << 1) | (a >>> 31))),
          (r = f ^ ((a << 1) | (i >>> 31))),
          (e[8] ^= n),
          (e[9] ^= r),
          (e[18] ^= n),
          (e[19] ^= r),
          (e[28] ^= n),
          (e[29] ^= r),
          (e[38] ^= n),
          (e[39] ^= r),
          (e[48] ^= n),
          (e[49] ^= r),
          (N = e[0]),
          (G = e[1]),
          (Pe = (e[11] << 4) | (e[10] >>> 28)),
          (Ee = (e[10] << 4) | (e[11] >>> 28)),
          (ge = (e[20] << 3) | (e[21] >>> 29)),
          (me = (e[21] << 3) | (e[20] >>> 29)),
          (Ue = (e[31] << 9) | (e[30] >>> 23)),
          (De = (e[30] << 9) | (e[31] >>> 23)),
          (we = (e[40] << 18) | (e[41] >>> 14)),
          (ke = (e[41] << 18) | (e[40] >>> 14)),
          (fe = (e[2] << 1) | (e[3] >>> 31)),
          (de = (e[3] << 1) | (e[2] >>> 31)),
          (Y = (e[13] << 12) | (e[12] >>> 20)),
          (K = (e[12] << 12) | (e[13] >>> 20)),
          (Be = (e[22] << 10) | (e[23] >>> 22)),
          (_e = (e[23] << 10) | (e[22] >>> 22)),
          (Ae = (e[33] << 13) | (e[32] >>> 19)),
          (le = (e[32] << 13) | (e[33] >>> 19)),
          (We = (e[42] << 2) | (e[43] >>> 30)),
          (qe = (e[43] << 2) | (e[42] >>> 30)),
          ($e = (e[5] << 30) | (e[4] >>> 2)),
          (Fe = (e[4] << 30) | (e[5] >>> 2)),
          (xe = (e[14] << 6) | (e[15] >>> 26)),
          (he = (e[15] << 6) | (e[14] >>> 26)),
          (Q = (e[25] << 11) | (e[24] >>> 21)),
          (X = (e[24] << 11) | (e[25] >>> 21)),
          (Te = (e[34] << 15) | (e[35] >>> 17)),
          (je = (e[35] << 15) | (e[34] >>> 17)),
          (ce = (e[45] << 29) | (e[44] >>> 3)),
          (ue = (e[44] << 29) | (e[45] >>> 3)),
          (ae = (e[6] << 28) | (e[7] >>> 4)),
          (ie = (e[7] << 28) | (e[6] >>> 4)),
          (Re = (e[17] << 23) | (e[16] >>> 9)),
          (Me = (e[16] << 23) | (e[17] >>> 9)),
          (pe = (e[26] << 25) | (e[27] >>> 7)),
          (be = (e[27] << 25) | (e[26] >>> 7)),
          (ee = (e[36] << 21) | (e[37] >>> 11)),
          (re = (e[37] << 21) | (e[36] >>> 11)),
          (Oe = (e[47] << 24) | (e[46] >>> 8)),
          (Ne = (e[46] << 24) | (e[47] >>> 8)),
          (Ce = (e[8] << 27) | (e[9] >>> 5)),
          (Se = (e[9] << 27) | (e[8] >>> 5)),
          (oe = (e[18] << 20) | (e[19] >>> 12)),
          (te = (e[19] << 20) | (e[18] >>> 12)),
          (Ie = (e[29] << 7) | (e[28] >>> 25)),
          (Le = (e[28] << 7) | (e[29] >>> 25)),
          (ye = (e[38] << 8) | (e[39] >>> 24)),
          (ve = (e[39] << 8) | (e[38] >>> 24)),
          (se = (e[48] << 14) | (e[49] >>> 18)),
          (ne = (e[49] << 14) | (e[48] >>> 18)),
          (e[0] = N ^ (~Y & Q)),
          (e[1] = G ^ (~K & X)),
          (e[10] = ae ^ (~oe & ge)),
          (e[11] = ie ^ (~te & me)),
          (e[20] = fe ^ (~xe & pe)),
          (e[21] = de ^ (~he & be)),
          (e[30] = Ce ^ (~Pe & Be)),
          (e[31] = Se ^ (~Ee & _e)),
          (e[40] = $e ^ (~Re & Ie)),
          (e[41] = Fe ^ (~Me & Le)),
          (e[2] = Y ^ (~Q & ee)),
          (e[3] = K ^ (~X & re)),
          (e[12] = oe ^ (~ge & Ae)),
          (e[13] = te ^ (~me & le)),
          (e[22] = xe ^ (~pe & ye)),
          (e[23] = he ^ (~be & ve)),
          (e[32] = Pe ^ (~Be & Te)),
          (e[33] = Ee ^ (~_e & je)),
          (e[42] = Re ^ (~Ie & Ue)),
          (e[43] = Me ^ (~Le & De)),
          (e[4] = Q ^ (~ee & se)),
          (e[5] = X ^ (~re & ne)),
          (e[14] = ge ^ (~Ae & ce)),
          (e[15] = me ^ (~le & ue)),
          (e[24] = pe ^ (~ye & we)),
          (e[25] = be ^ (~ve & ke)),
          (e[34] = Be ^ (~Te & Oe)),
          (e[35] = _e ^ (~je & Ne)),
          (e[44] = Ie ^ (~Ue & We)),
          (e[45] = Le ^ (~De & qe)),
          (e[6] = ee ^ (~se & N)),
          (e[7] = re ^ (~ne & G)),
          (e[16] = Ae ^ (~ce & ae)),
          (e[17] = le ^ (~ue & ie)),
          (e[26] = ye ^ (~we & fe)),
          (e[27] = ve ^ (~ke & de)),
          (e[36] = Te ^ (~Oe & Ce)),
          (e[37] = je ^ (~Ne & Se)),
          (e[46] = Ue ^ (~We & $e)),
          (e[47] = De ^ (~qe & Fe)),
          (e[8] = se ^ (~N & Y)),
          (e[9] = ne ^ (~G & K)),
          (e[18] = ce ^ (~ae & oe)),
          (e[19] = ue ^ (~ie & te)),
          (e[28] = we ^ (~fe & xe)),
          (e[29] = ke ^ (~de & he)),
          (e[38] = Oe ^ (~Ce & Pe)),
          (e[39] = Ne ^ (~Se & Ee)),
          (e[48] = We ^ (~$e & Re)),
          (e[49] = qe ^ (~Fe & Me)),
          (e[0] ^= R[s]),
          (e[1] ^= R[s + 1]);
    };
    for (w = 0; w < T.length; ++w) x[T[w]] = B[T[w]];
    Ve &&
      define(function () {
        return B;
      });
  })();
  (() => {
    var A = Object.create,
      d = Object.defineProperty,
      E = Object.getOwnPropertyDescriptor,
      _ = Object.getOwnPropertyNames,
      x = Object.getPrototypeOf,
      ze = Object.prototype.hasOwnProperty,
      Je = (g, l) => () => (
        l || g((l = { exports: {} }).exports, l), l.exports
      ),
      Ve = (g, l, u, p) => {
        if ((l && typeof l == "object") || typeof l == "function")
          for (let y of _(l))
            !ze.call(g, y) &&
              y !== u &&
              d(g, y, {
                get: () => l[y],
                enumerable: !(p = E(l, y)) || p.enumerable,
              });
        return g;
      },
      U = (g, l, u) => (
        (u = g != null ? A(x(g)) : {}),
        Ve(
          l || !g || !g.__esModule
            ? d(u, "default", { value: g, enumerable: !0 })
            : u,
          g,
        )
      ),
      h = Je((g, l) => {
        (function (u, p) {
          if (typeof define == "function" && define.amd)
            define("webextension-polyfill", ["module"], p);
          else if (typeof g < "u") p(l);
          else {
            var y = { exports: {} };
            p(y), (u.browser = y.exports);
          }
        })(
          typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : g,
          function (u) {
            "use strict";
            if (!globalThis.chrome?.runtime?.id)
              throw new Error(
                "This script should only be loaded in a browser extension.",
              );
            if (
              typeof globalThis.browser > "u" ||
              Object.getPrototypeOf(globalThis.browser) !== Object.prototype
            ) {
              let p = "The message port closed before a response was received.",
                y = (S) => {
                  let M = {
                    alarms: {
                      clear: { minArgs: 0, maxArgs: 1 },
                      clearAll: { minArgs: 0, maxArgs: 0 },
                      get: { minArgs: 0, maxArgs: 1 },
                      getAll: { minArgs: 0, maxArgs: 0 },
                    },
                    bookmarks: {
                      create: { minArgs: 1, maxArgs: 1 },
                      get: { minArgs: 1, maxArgs: 1 },
                      getChildren: { minArgs: 1, maxArgs: 1 },
                      getRecent: { minArgs: 1, maxArgs: 1 },
                      getSubTree: { minArgs: 1, maxArgs: 1 },
                      getTree: { minArgs: 0, maxArgs: 0 },
                      move: { minArgs: 2, maxArgs: 2 },
                      remove: { minArgs: 1, maxArgs: 1 },
                      removeTree: { minArgs: 1, maxArgs: 1 },
                      search: { minArgs: 1, maxArgs: 1 },
                      update: { minArgs: 2, maxArgs: 2 },
                    },
                    browserAction: {
                      disable: {
                        minArgs: 0,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      enable: {
                        minArgs: 0,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 },
                      getBadgeText: { minArgs: 1, maxArgs: 1 },
                      getPopup: { minArgs: 1, maxArgs: 1 },
                      getTitle: { minArgs: 1, maxArgs: 1 },
                      openPopup: { minArgs: 0, maxArgs: 0 },
                      setBadgeBackgroundColor: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      setBadgeText: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      setIcon: { minArgs: 1, maxArgs: 1 },
                      setPopup: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      setTitle: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                    },
                    browsingData: {
                      remove: { minArgs: 2, maxArgs: 2 },
                      removeCache: { minArgs: 1, maxArgs: 1 },
                      removeCookies: { minArgs: 1, maxArgs: 1 },
                      removeDownloads: { minArgs: 1, maxArgs: 1 },
                      removeFormData: { minArgs: 1, maxArgs: 1 },
                      removeHistory: { minArgs: 1, maxArgs: 1 },
                      removeLocalStorage: { minArgs: 1, maxArgs: 1 },
                      removePasswords: { minArgs: 1, maxArgs: 1 },
                      removePluginData: { minArgs: 1, maxArgs: 1 },
                      settings: { minArgs: 0, maxArgs: 0 },
                    },
                    commands: { getAll: { minArgs: 0, maxArgs: 0 } },
                    contextMenus: {
                      remove: { minArgs: 1, maxArgs: 1 },
                      removeAll: { minArgs: 0, maxArgs: 0 },
                      update: { minArgs: 2, maxArgs: 2 },
                    },
                    cookies: {
                      get: { minArgs: 1, maxArgs: 1 },
                      getAll: { minArgs: 1, maxArgs: 1 },
                      getAllCookieStores: { minArgs: 0, maxArgs: 0 },
                      remove: { minArgs: 1, maxArgs: 1 },
                      set: { minArgs: 1, maxArgs: 1 },
                    },
                    devtools: {
                      inspectedWindow: {
                        eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: !1 },
                      },
                      panels: {
                        create: {
                          minArgs: 3,
                          maxArgs: 3,
                          singleCallbackArg: !0,
                        },
                        elements: {
                          createSidebarPane: { minArgs: 1, maxArgs: 1 },
                        },
                      },
                    },
                    downloads: {
                      cancel: { minArgs: 1, maxArgs: 1 },
                      download: { minArgs: 1, maxArgs: 1 },
                      erase: { minArgs: 1, maxArgs: 1 },
                      getFileIcon: { minArgs: 1, maxArgs: 2 },
                      open: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      pause: { minArgs: 1, maxArgs: 1 },
                      removeFile: { minArgs: 1, maxArgs: 1 },
                      resume: { minArgs: 1, maxArgs: 1 },
                      search: { minArgs: 1, maxArgs: 1 },
                      show: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                    },
                    extension: {
                      isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 },
                      isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 },
                    },
                    history: {
                      addUrl: { minArgs: 1, maxArgs: 1 },
                      deleteAll: { minArgs: 0, maxArgs: 0 },
                      deleteRange: { minArgs: 1, maxArgs: 1 },
                      deleteUrl: { minArgs: 1, maxArgs: 1 },
                      getVisits: { minArgs: 1, maxArgs: 1 },
                      search: { minArgs: 1, maxArgs: 1 },
                    },
                    i18n: {
                      detectLanguage: { minArgs: 1, maxArgs: 1 },
                      getAcceptLanguages: { minArgs: 0, maxArgs: 0 },
                    },
                    identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } },
                    idle: { queryState: { minArgs: 1, maxArgs: 1 } },
                    management: {
                      get: { minArgs: 1, maxArgs: 1 },
                      getAll: { minArgs: 0, maxArgs: 0 },
                      getSelf: { minArgs: 0, maxArgs: 0 },
                      setEnabled: { minArgs: 2, maxArgs: 2 },
                      uninstallSelf: { minArgs: 0, maxArgs: 1 },
                    },
                    notifications: {
                      clear: { minArgs: 1, maxArgs: 1 },
                      create: { minArgs: 1, maxArgs: 2 },
                      getAll: { minArgs: 0, maxArgs: 0 },
                      getPermissionLevel: { minArgs: 0, maxArgs: 0 },
                      update: { minArgs: 2, maxArgs: 2 },
                    },
                    pageAction: {
                      getPopup: { minArgs: 1, maxArgs: 1 },
                      getTitle: { minArgs: 1, maxArgs: 1 },
                      hide: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      setIcon: { minArgs: 1, maxArgs: 1 },
                      setPopup: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      setTitle: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                      show: {
                        minArgs: 1,
                        maxArgs: 1,
                        fallbackToNoCallback: !0,
                      },
                    },
                    permissions: {
                      contains: { minArgs: 1, maxArgs: 1 },
                      getAll: { minArgs: 0, maxArgs: 0 },
                      remove: { minArgs: 1, maxArgs: 1 },
                      request: { minArgs: 1, maxArgs: 1 },
                    },
                    runtime: {
                      getBackgroundPage: { minArgs: 0, maxArgs: 0 },
                      getPlatformInfo: { minArgs: 0, maxArgs: 0 },
                      openOptionsPage: { minArgs: 0, maxArgs: 0 },
                      requestUpdateCheck: { minArgs: 0, maxArgs: 0 },
                      sendMessage: { minArgs: 1, maxArgs: 3 },
                      sendNativeMessage: { minArgs: 2, maxArgs: 2 },
                      setUninstallURL: { minArgs: 1, maxArgs: 1 },
                    },
                    sessions: {
                      getDevices: { minArgs: 0, maxArgs: 1 },
                      getRecentlyClosed: { minArgs: 0, maxArgs: 1 },
                      restore: { minArgs: 0, maxArgs: 1 },
                    },
                    storage: {
                      local: {
                        clear: { minArgs: 0, maxArgs: 0 },
                        get: { minArgs: 0, maxArgs: 1 },
                        getBytesInUse: { minArgs: 0, maxArgs: 1 },
                        remove: { minArgs: 1, maxArgs: 1 },
                        set: { minArgs: 1, maxArgs: 1 },
                      },
                      managed: {
                        get: { minArgs: 0, maxArgs: 1 },
                        getBytesInUse: { minArgs: 0, maxArgs: 1 },
                      },
                      sync: {
                        clear: { minArgs: 0, maxArgs: 0 },
                        get: { minArgs: 0, maxArgs: 1 },
                        getBytesInUse: { minArgs: 0, maxArgs: 1 },
                        remove: { minArgs: 1, maxArgs: 1 },
                        set: { minArgs: 1, maxArgs: 1 },
                      },
                    },
                    tabs: {
                      captureVisibleTab: { minArgs: 0, maxArgs: 2 },
                      create: { minArgs: 1, maxArgs: 1 },
                      detectLanguage: { minArgs: 0, maxArgs: 1 },
                      discard: { minArgs: 0, maxArgs: 1 },
                      duplicate: { minArgs: 1, maxArgs: 1 },
                      executeScript: { minArgs: 1, maxArgs: 2 },
                      get: { minArgs: 1, maxArgs: 1 },
                      getCurrent: { minArgs: 0, maxArgs: 0 },
                      getZoom: { minArgs: 0, maxArgs: 1 },
                      getZoomSettings: { minArgs: 0, maxArgs: 1 },
                      goBack: { minArgs: 0, maxArgs: 1 },
                      goForward: { minArgs: 0, maxArgs: 1 },
                      highlight: { minArgs: 1, maxArgs: 1 },
                      insertCSS: { minArgs: 1, maxArgs: 2 },
                      move: { minArgs: 2, maxArgs: 2 },
                      query: { minArgs: 1, maxArgs: 1 },
                      reload: { minArgs: 0, maxArgs: 2 },
                      remove: { minArgs: 1, maxArgs: 1 },
                      removeCSS: { minArgs: 1, maxArgs: 2 },
                      sendMessage: { minArgs: 2, maxArgs: 3 },
                      setZoom: { minArgs: 1, maxArgs: 2 },
                      setZoomSettings: { minArgs: 1, maxArgs: 2 },
                      update: { minArgs: 1, maxArgs: 2 },
                    },
                    topSites: { get: { minArgs: 0, maxArgs: 0 } },
                    webNavigation: {
                      getAllFrames: { minArgs: 1, maxArgs: 1 },
                      getFrame: { minArgs: 1, maxArgs: 1 },
                    },
                    webRequest: {
                      handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 },
                    },
                    windows: {
                      create: { minArgs: 0, maxArgs: 1 },
                      get: { minArgs: 1, maxArgs: 2 },
                      getAll: { minArgs: 0, maxArgs: 1 },
                      getCurrent: { minArgs: 0, maxArgs: 1 },
                      getLastFocused: { minArgs: 0, maxArgs: 1 },
                      remove: { minArgs: 1, maxArgs: 1 },
                      update: { minArgs: 2, maxArgs: 2 },
                    },
                  };
                  if (Object.keys(M).length === 0)
                    throw new Error(
                      "api-metadata.json has not been included in browser-polyfill",
                    );
                  class W extends WeakMap {
                    constructor(s, i = void 0) {
                      super(i), (this.createItem = s);
                    }
                    get(s) {
                      return (
                        this.has(s) || this.set(s, this.createItem(s)),
                        super.get(s)
                      );
                    }
                  }
                  let I = (r) =>
                      r && typeof r == "object" && typeof r.then == "function",
                    q =
                      (r, s) =>
                      (...i) => {
                        S.runtime.lastError
                          ? r.reject(new Error(S.runtime.lastError.message))
                          : s.singleCallbackArg ||
                              (i.length <= 1 && s.singleCallbackArg !== !1)
                            ? r.resolve(i[0])
                            : r.resolve(i);
                      },
                    $ = (r) => (r == 1 ? "argument" : "arguments"),
                    B = (r, s) =>
                      function (i, ...a) {
                        if (a.length < s.minArgs)
                          throw new Error(
                            `Expected at least ${s.minArgs} ${$(s.minArgs)} for ${r}(), got ${a.length}`,
                          );
                        if (a.length > s.maxArgs)
                          throw new Error(
                            `Expected at most ${s.maxArgs} ${$(s.maxArgs)} for ${r}(), got ${a.length}`,
                          );
                        return new Promise((o, m) => {
                          if (s.fallbackToNoCallback)
                            try {
                              i[r](...a, q({ resolve: o, reject: m }, s));
                            } catch {
                              i[r](...a),
                                (s.fallbackToNoCallback = !1),
                                (s.noCallback = !0),
                                o();
                            }
                          else
                            s.noCallback
                              ? (i[r](...a), o())
                              : i[r](...a, q({ resolve: o, reject: m }, s));
                        });
                      },
                    T = (r, s, i) =>
                      new Proxy(s, {
                        apply(a, o, m) {
                          return i.call(o, r, ...m);
                        },
                      }),
                    w = Function.call.bind(Object.prototype.hasOwnProperty),
                    P = (r, s = {}, i = {}) => {
                      let a = Object.create(null),
                        o = {
                          has(c, t) {
                            return t in r || t in a;
                          },
                          get(c, t, b) {
                            if (t in a) return a[t];
                            if (!(t in r)) return;
                            let f = r[t];
                            if (typeof f == "function")
                              if (typeof s[t] == "function")
                                f = T(r, r[t], s[t]);
                              else if (w(i, t)) {
                                let k = B(t, i[t]);
                                f = T(r, r[t], k);
                              } else f = f.bind(r);
                            else if (
                              typeof f == "object" &&
                              f !== null &&
                              (w(s, t) || w(i, t))
                            )
                              f = P(f, s[t], i[t]);
                            else if (w(i, "*")) f = P(f, s[t], i["*"]);
                            else
                              return (
                                Object.defineProperty(a, t, {
                                  configurable: !0,
                                  enumerable: !0,
                                  get() {
                                    return r[t];
                                  },
                                  set(k) {
                                    r[t] = k;
                                  },
                                }),
                                f
                              );
                            return (a[t] = f), f;
                          },
                          set(c, t, b, f) {
                            return t in a ? (a[t] = b) : (r[t] = b), !0;
                          },
                          defineProperty(c, t, b) {
                            return Reflect.defineProperty(a, t, b);
                          },
                          deleteProperty(c, t) {
                            return Reflect.deleteProperty(a, t);
                          },
                        },
                        m = Object.create(r);
                      return new Proxy(m, o);
                    },
                    j = (r) => ({
                      addListener(s, i, ...a) {
                        s.addListener(r.get(i), ...a);
                      },
                      hasListener(s, i) {
                        return s.hasListener(r.get(i));
                      },
                      removeListener(s, i) {
                        s.removeListener(r.get(i));
                      },
                    }),
                    F = new W((r) =>
                      typeof r != "function"
                        ? r
                        : function (s) {
                            let i = P(
                              s,
                              {},
                              { getContent: { minArgs: 0, maxArgs: 0 } },
                            );
                            r(i);
                          },
                    ),
                    L = new W((r) =>
                      typeof r != "function"
                        ? r
                        : function (s, i, a) {
                            let o = !1,
                              m,
                              c = new Promise((k) => {
                                m = function (C) {
                                  (o = !0), k(C);
                                };
                              }),
                              t;
                            try {
                              t = r(s, i, m);
                            } catch (k) {
                              t = Promise.reject(k);
                            }
                            let b = t !== !0 && I(t);
                            return t !== !0 && !b && !o
                              ? !1
                              : (((k) => {
                                  k.then(
                                    (C) => {
                                      a(C);
                                    },
                                    (C) => {
                                      let N;
                                      C &&
                                      (C instanceof Error ||
                                        typeof C.message == "string")
                                        ? (N = C.message)
                                        : (N = "An unexpected error occurred"),
                                        a({
                                          __mozWebExtensionPolyfillReject__: !0,
                                          message: N,
                                        });
                                    },
                                  ).catch((C) => {});
                                })(b ? t : c),
                                !0);
                          },
                    ),
                    J = ({ reject: r, resolve: s }, i) => {
                      S.runtime.lastError
                        ? S.runtime.lastError.message === p
                          ? s()
                          : r(new Error(S.runtime.lastError.message))
                        : i && i.__mozWebExtensionPolyfillReject__
                          ? r(new Error(i.message))
                          : s(i);
                    },
                    O = (r, s, i, ...a) => {
                      if (a.length < s.minArgs)
                        throw new Error(
                          `Expected at least ${s.minArgs} ${$(s.minArgs)} for ${r}(), got ${a.length}`,
                        );
                      if (a.length > s.maxArgs)
                        throw new Error(
                          `Expected at most ${s.maxArgs} ${$(s.maxArgs)} for ${r}(), got ${a.length}`,
                        );
                      return new Promise((o, m) => {
                        let c = J.bind(null, { resolve: o, reject: m });
                        a.push(c), i.sendMessage(...a);
                      });
                    },
                    e = {
                      devtools: { network: { onRequestFinished: j(F) } },
                      runtime: {
                        onMessage: j(L),
                        onMessageExternal: j(L),
                        sendMessage: O.bind(null, "sendMessage", {
                          minArgs: 1,
                          maxArgs: 3,
                        }),
                      },
                      tabs: {
                        sendMessage: O.bind(null, "sendMessage", {
                          minArgs: 2,
                          maxArgs: 3,
                        }),
                      },
                    },
                    n = {
                      clear: { minArgs: 1, maxArgs: 1 },
                      get: { minArgs: 1, maxArgs: 1 },
                      set: { minArgs: 1, maxArgs: 1 },
                    };
                  return (
                    (M.privacy = {
                      network: { "*": n },
                      services: { "*": n },
                      websites: { "*": n },
                    }),
                    P(S, e, M)
                  );
                };
              u.exports = y(chrome);
            } else u.exports = globalThis.browser;
          },
        );
      }),
      z = U(h()),
      v = U(h()),
      R = null,
      V = class {
        constructor() {
          (this.enforcement = void 0),
            (this.pendingPromises = []),
            (window.useArkoseSetupEnforcement =
              this.useArkoseSetupEnforcement.bind(this)),
            (this.enforcementPromise = new Promise((g) => {
              R = g;
            })),
            this.injectScript();
        }
        useArkoseSetupEnforcement(g) {
          (this.enforcement = g),
            g.setConfig({
              onCompleted: (l) => {
                this.pendingPromises.forEach((u) => {
                  u.resolve(l.token);
                }),
                  (this.pendingPromises = []);
              },
              onReady: () => {
                R?.(), (R = null);
              },
              onError: (l) => {},
              onFailed: (l) => {
                this.pendingPromises.forEach((u) => {
                  u.reject(new Error("Failed to generate arkose token"));
                });
              },
            });
        }
        injectScript() {
          let g = document.createElement("script");
          (g.src = chrome.runtime.getURL("/api.js")),
            (g.async = !0),
            (g.defer = !0),
            g.setAttribute("data-callback", "useArkoseSetupEnforcement"),
            document.body.appendChild(g);
        }
        async generate() {
          let g = !1,
            l = setTimeout(() => {
              g = !0;
            }, 1e4);
          try {
            await this.enforcementPromise;
          } catch {
            throw new Error("Failed to generate arkose token");
          }
          if ((clearTimeout(l), g))
            throw new Error("Generate arkose token timeout");
          return new Promise((u) => {
            (this.pendingPromises = [{ resolve: u }]), this.enforcement.run();
          });
        }
      },
      D = new V();
    async function H() {
      return (await D.generate()) || null;
    }
    z.default.runtime.onMessage.addListener((g) => {
      if (g.type === "getArkoseToken") return H().then((l) => l);
      if (g.type === "getProofToken")
        return He(g.params[0], g.params[1]).then((l) => l);
    });
    function Z() {
      return [
        navigator.hardwareConcurrency + screen.width + screen.height,
        new Date().toString(),
        4294705152,
        0,
        navigator.userAgent,
      ];
    }
    async function He(g, l) {
      let u = Z();
      for (let p = 0; p < 1e5; p++) {
        u[3] = p;
        let y = JSON.stringify(u),
          S = btoa(String.fromCharCode(...new TextEncoder().encode(y)));
        if (sha3_512(g + S).slice(0, l.length) <= l) return `gAAAAAB${S}`;
      }
      return `gAAAAABwQ8Lk5FbGpA2NcR9dShT6gYjU7VxZ4D${btoa(g)}`;
    }
  })();
})();
/**
 * [js-sha3]{@link https://github.com/emn178/js-sha3}
 *
 * @version 0.9.3
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2015-2023
 * @license MIT
 */
