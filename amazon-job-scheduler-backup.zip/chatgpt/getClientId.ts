import { v4 as uuidv4 } from "uuid";

/**
 * Returns a persistent client ID stored in localStorage.
 * If not already set, a new UUID is generated and stored.
 */
export function getClientId(): string {
  const storageKey = "client_id";

  let clientId = localStorage.getItem(storageKey);
  if (!clientId) {
    clientId = uuidv4();
    localStorage.setItem(storageKey, clientId);
  }

  return clientId;
}
