interface ServerMessageData {
  conversation_id: string;
  message_id: string;
  response_id: string;
  body: string;
}

interface ProcessedMessage {
  conversationId: string;
  messageId: string;
  responseId: string;
  body: string;
}

interface Callbacks {
  onServerData: (data: ProcessedMessage) => void;
}

// Assuming WebSocketClient has these methods and event bindings
interface WebSocketClient {
  start(): void;
  stop(): void;
  on(
    event: "server-message" | "group-message",
    callback: (event: { message: { data: ServerMessageData } }) => void,
  ): void;
}

declare class WebSocketClientImpl implements WebSocketClient {
  constructor(serverUrl: string);
  start(): void;
  stop(): void;
  on(
    event: "server-message" | "group-message",
    callback: (event: { message: { data: ServerMessageData } }) => void,
  ): void;
}

export class WebSocketMessageHandler {
  private client: WebSocketClient | null = null;
  private initialized: boolean = false;
  private onServerData: (data: ProcessedMessage) => void = () => {};

  /**
   * Connects to the WebSocket server and initializes message listeners.
   *
   * @param serverUrl - The URL of the WebSocket server.
   * @param callbacks - Callback handlers.
   */
  connect(serverUrl: string, callbacks: Callbacks): void {
    this.onServerData = callbacks.onServerData;

    if (!this.initialized) {
      this.client = new WebSocketClientImpl(serverUrl);
      this.initialized = true;

      const handleMessage = (event: {
        message: { data: ServerMessageData };
      }) => {
        const data = event.message.data;
        this.onServerData({
          conversationId: data.conversation_id,
          messageId: data.message_id,
          responseId: data.response_id,
          body: data.body,
        });
      };

      this.client.on("server-message", handleMessage);
      this.client.on("group-message", handleMessage);

      this.start();
    }
  }

  /**
   * Stops the WebSocket client if initialized.
   */
  stop(): void {
    this.client?.stop();
  }

  /**
   * Starts the WebSocket client if initialized.
   */
  start(): void {
    this.client?.start();
  }
}
